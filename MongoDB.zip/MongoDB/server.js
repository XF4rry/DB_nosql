var express = require('express');

const { MongoClient, ServerApiVersion } = require('mongodb');
const url = "mongodb+srv://LilNigga:FATIHA01@nigga.lyz9vda.mongodb.net/?retryWrites=true&w=majority&appName=Nigga";


const Animale = require('./modelli/animale')
const mongoose = require('mongoose')

const connectionParams={
    useNewUrlParser: true,
    useUnifiedTopology: true
}


mongoose.connect(url, connectionParams)
    .then(  () => {
        console.log("Connected to the DB");
    })
    .catch( (err) => {
        console.error("erroe connecting to the db, error n: " + err);
    })

var app=express();

const axios=require('axios');

const bodyParser=require('body-parser');

const ejs=require('ejs')

app.set('view engine','ejs');

app.use(bodyParser.urlencoded({
    extended:true
}));

app.use(express.static(__dirname+'/public'));

app.get('/',function(req,res){
    Animale.find()
        .sort({dataacquisto:-1})
        .then(items => console.log(items))
    res.render("pages/index", {
    })
});

app.post("/", function(req,res){
    const newAnimale = new Animale({
        username: req.body.username,
        password: req.body.password,
        presente:true
    })
    newAnimale
    .save()
    .then(item => console.log(item))
    .catch(err => console.log(err));
})

app.listen(5000);
console.log('server in ascolto sulla porta 5000')